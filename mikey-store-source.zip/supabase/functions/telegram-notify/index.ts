// Sends a formatted notification to the admin Telegram chat
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const TG_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN")!;
const ADMIN_CHAT = Deno.env.get("TELEGRAM_ADMIN_CHAT_ID")!;

interface Payload {
  kind: "credit" | "topup" | "purchase";
  request_id: string;
  email: string;
  product: string;
  duration?: string;
  price: number | string;
  quantity?: number;
  transaction_code?: string;
  game_uid?: string;
  extra?: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const p: Payload = await req.json();
    const lines = [
      `🔔 *NEW ${p.kind.toUpperCase()} REQUEST*`,
      ``,
      `👤 Gmail: \`${p.email}\``,
      `📦 Product: ${p.product}`,
    ];
    if (p.duration) lines.push(`⏰ Duration: ${p.duration}`);
    lines.push(`💰 Price: Rs. ${p.price}`);
    if (p.quantity) lines.push(`🔢 Quantity: ${p.quantity}`);
    if (p.game_uid) lines.push(`🎮 Game UID: \`${p.game_uid}\``);
    if (p.transaction_code) lines.push(`🧾 Txn Code: \`${p.transaction_code}\``);
    if (p.extra) lines.push(p.extra);
    lines.push(``, `Status: ⏳ Pending`);

    const keyboard = {
      inline_keyboard: [[
        { text: "✅ Approve", callback_data: `approve:${p.kind}:${p.request_id}` },
        { text: "❌ Reject", callback_data: `reject:${p.kind}:${p.request_id}` },
      ]],
    };

    const r = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: ADMIN_CHAT,
        text: lines.join("\n"),
        parse_mode: "Markdown",
        reply_markup: keyboard,
      }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(JSON.stringify(data));

    // Mark notified
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const table = p.kind === "credit" ? "credit_requests" : p.kind === "topup" ? "topup_requests" : "transactions";
    await supabase.from(table).update({ notified_at: new Date().toISOString() }).eq("id", p.request_id);

    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("notify error", e);
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
