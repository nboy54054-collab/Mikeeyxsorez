// Verifies a one-time access code (issued by admin or bot) and returns a magic-link token + scope
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { email, code } = await req.json();
    if (!email || !code) throw new Error("email and code required");
    const emailLc = String(email).toLowerCase().trim();
    const codeStr = String(code).trim();

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: ac } = await supabase
      .from("access_codes")
      .select("*")
      .eq("email", emailLc)
      .eq("code", codeStr)
      .eq("used", false)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!ac) throw new Error("Invalid, used or expired code");

    // Find or create user
    const { data: usersList } = await supabase.auth.admin.listUsers({ page: 1, perPage: 500 });
    let user = usersList?.users.find((u) => (u.email || "").toLowerCase() === emailLc);
    if (!user) {
      const { data: created, error: cErr } = await supabase.auth.admin.createUser({
        email: emailLc, email_confirm: true,
      });
      if (cErr) throw cErr;
      user = created.user!;
    }

    // Mark used
    await supabase.from("access_codes").update({ used: true, used_at: new Date().toISOString() }).eq("id", ac.id);

    // Update profile: approved + scope
    await supabase.from("profiles").upsert(
      { user_id: user.id, email: emailLc, is_approved: true, access_scope: ac.scope },
      { onConflict: "user_id" },
    );

    // Generate magic link
    const { data: link, error: linkErr } = await supabase.auth.admin.generateLink({
      type: "magiclink", email: emailLc,
    });
    if (linkErr || !link) throw linkErr || new Error("Failed to generate session");

    return new Response(
      JSON.stringify({
        ok: true,
        email: emailLc,
        scope: ac.scope,
        token_hash: link.properties?.hashed_token,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String((e as any)?.message || e) }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
