// Verify a Telegram-issued OTP and return a session for the user
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { email, code } = await req.json();
    if (!email || !code) throw new Error("email and code required");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: otp } = await supabase
      .from("telegram_otps")
      .select("*")
      .eq("email", String(email).toLowerCase())
      .eq("code", String(code))
      .eq("used", false)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!otp) throw new Error("Invalid or expired code");

    // Mark used
    await supabase.from("telegram_otps").update({ used: true }).eq("id", otp.id);

    // Auto-link telegram chat to user if not linked yet
    const { data: users } = await supabase.auth.admin.listUsers({ page: 1, perPage: 200 });
    const user = users?.users.find((u) => (u.email || "").toLowerCase() === otp.email);
    if (!user) throw new Error("Account not found");
    await supabase.from("telegram_links").upsert(
      { user_id: user.id, email: otp.email, telegram_chat_id: otp.telegram_chat_id },
      { onConflict: "email" },
    );
    // Ensure approved so they can log in
    await supabase.from("profiles").update({ is_approved: true }).eq("user_id", user.id);

    // Generate magic link tokens to sign the user in
    const { data: link, error: linkErr } = await supabase.auth.admin.generateLink({
      type: "magiclink",
      email: otp.email,
    });
    if (linkErr || !link) throw linkErr || new Error("Failed to generate link");

    return new Response(
      JSON.stringify({
        ok: true,
        email: otp.email,
        token_hash: link.properties?.hashed_token,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e?.message || e) }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
