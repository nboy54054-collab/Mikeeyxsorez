// Polls Telegram getUpdates; commands: /start /login /code /issue /check /link
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const TG_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN")!;
const ADMIN_CHAT = Deno.env.get("TELEGRAM_ADMIN_CHAT_ID")!;
const TG = `https://api.telegram.org/bot${TG_TOKEN}`;
const MAX_RUNTIME = 55_000;

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

async function tg(method: string, body: unknown) {
  const r = await fetch(`${TG}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

function genCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function isAdminChat(chatId: number | string) {
  return String(chatId) === String(ADMIN_CHAT);
}

async function findUserByEmail(email: string) {
  const { data } = await supabase.auth.admin.listUsers({ page: 1, perPage: 500 });
  return data?.users.find((u) => (u.email || "").toLowerCase() === email.toLowerCase());
}

async function handleMessage(msg: any) {
  const chatId = msg.chat.id;
  const text: string = (msg.text || "").trim();
  const username = msg.from?.username;

  if (text.startsWith("/start") || text === "/help") {
    const adminHelp = isAdminChat(chatId)
      ? "\n\n*Admin:*\n• `/issue gmail credit` — issue credit access code\n• `/issue gmail topup` — issue topup access code\n• `/check` — show pending requests\n• `/link gmail` — link this chat to user"
      : "";
    await tg("sendMessage", {
      chat_id: chatId,
      text:
        "👋 *Mikey Store Bot*\n\nCommands:\n• `/login your@gmail.com` — request access code (admin issues it)\n• `/code XXXXXX` — show details of an issued code" + adminHelp,
      parse_mode: "Markdown",
    });
    return;
  }

  // /login <gmail> — user requests, notifies admin (admin then issues via /issue)
  if (text.startsWith("/login")) {
    const email = text.split(/\s+/)[1]?.toLowerCase();
    if (!email || !email.includes("@")) {
      await tg("sendMessage", { chat_id: chatId, text: "❌ Usage: /login your@gmail.com" });
      return;
    }
    // Notify admin
    await tg("sendMessage", {
      chat_id: ADMIN_CHAT,
      text: `🔔 *Login request*\n\n👤 ${email}\nFrom chat: \`${chatId}\` (${username || "no username"})\n\nIssue:\n• \`/issue ${email} credit\`\n• \`/issue ${email} topup\``,
      parse_mode: "Markdown",
    });
    await tg("sendMessage", { chat_id: chatId, text: "✅ Request sent. Admin will issue your code soon." });
    return;
  }

  // /issue <gmail> <credit|topup>  — admin only
  if (text.startsWith("/issue")) {
    if (!isAdminChat(chatId)) {
      await tg("sendMessage", { chat_id: chatId, text: "❌ Admin only" });
      return;
    }
    const parts = text.split(/\s+/);
    const email = parts[1]?.toLowerCase();
    const scope = parts[2]?.toLowerCase();
    if (!email || !["credit", "topup"].includes(scope)) {
      await tg("sendMessage", { chat_id: chatId, text: "Usage: /issue gmail credit|topup" });
      return;
    }
    const code = genCode();
    const { error } = await supabase.from("access_codes").insert({
      code, scope, email, issued_via: "telegram",
    });
    if (error) {
      await tg("sendMessage", { chat_id: chatId, text: `❌ ${error.message}` });
      return;
    }
    await tg("sendMessage", {
      chat_id: chatId,
      text: `✅ Issued *${scope}* code for \`${email}\`:\n\n🔐 \`${code}\`\n\nValid 24h, one-time use.`,
      parse_mode: "Markdown",
    });
    return;
  }

  // /code <code> — anyone can query
  if (text.startsWith("/code")) {
    const code = text.split(/\s+/)[1];
    if (!code) { await tg("sendMessage", { chat_id: chatId, text: "Usage: /code XXXXXX" }); return; }
    const { data: ac } = await supabase.from("access_codes").select("*").eq("code", code).maybeSingle();
    if (!ac) { await tg("sendMessage", { chat_id: chatId, text: "❌ Code not found" }); return; }
    const status = ac.used ? "USED" : (new Date(ac.expires_at) < new Date() ? "EXPIRED" : "ACTIVE");
    await tg("sendMessage", {
      chat_id: chatId,
      text: `🔐 Code \`${ac.code}\`\n👤 ${ac.email}\n🎯 Scope: ${ac.scope}\n📌 Status: ${status}\n⏰ Expires: ${new Date(ac.expires_at).toLocaleString()}`,
      parse_mode: "Markdown",
    });
    return;
  }

  // /check — admin only — list pending
  if (text.startsWith("/check")) {
    if (!isAdminChat(chatId)) { await tg("sendMessage", { chat_id: chatId, text: "❌ Admin only" }); return; }
    const [{ data: cr }, { data: tr }] = await Promise.all([
      supabase.from("credit_requests").select("id,transaction_code,amount_paid,package_amount,created_at").eq("status", "pending").order("created_at", { ascending: false }).limit(10),
      supabase.from("topup_requests").select("id,transaction_code,amount_paid,product_name,game_uid,created_at").eq("status", "pending").order("created_at", { ascending: false }).limit(10),
    ]);
    let out = "📋 *Pending Requests*\n\n";
    out += `*Credit (${cr?.length || 0}):*\n`;
    (cr || []).forEach((r: any) => {
      out += `• \`${r.transaction_code || r.id.slice(0, 6)}\` Rs.${r.amount_paid}/${r.package_amount}\n`;
    });
    out += `\n*Topup (${tr?.length || 0}):*\n`;
    (tr || []).forEach((r: any) => {
      out += `• \`${r.transaction_code || r.id.slice(0, 6)}\` ${r.product_name} - ${r.game_uid} Rs.${r.amount_paid}\n`;
    });
    await tg("sendMessage", { chat_id: chatId, text: out, parse_mode: "Markdown" });
    return;
  }

  if (text.startsWith("/link")) {
    const email = text.split(/\s+/)[1]?.toLowerCase();
    if (!email || !email.includes("@")) {
      await tg("sendMessage", { chat_id: chatId, text: "Usage: /link your@gmail.com" }); return;
    }
    const user = await findUserByEmail(email);
    if (!user) { await tg("sendMessage", { chat_id: chatId, text: "❌ Account not found" }); return; }
    await supabase.from("telegram_links").upsert(
      { user_id: user.id, email, telegram_chat_id: chatId, telegram_username: username },
      { onConflict: "email" },
    );
    await tg("sendMessage", { chat_id: chatId, text: "✅ Telegram linked." });
    return;
  }

  await tg("sendMessage", { chat_id: chatId, text: "Unknown command. Try /start" });
}

async function handleCallback(cb: any) {
  const data: string = cb.data || "";
  const chatId = cb.message?.chat?.id;
  const msgId = cb.message?.message_id;
  const fromChat = String(cb.from?.id);

  if (!isAdminChat(fromChat)) {
    await tg("answerCallbackQuery", { callback_query_id: cb.id, text: "Not authorized.", show_alert: true });
    return;
  }

  const [action, kind, id] = data.split(":");
  if (!["approve", "reject"].includes(action)) return;

  let resultMsg = "";
  try {
    if (kind === "credit") {
      const { data: cr } = await supabase.from("credit_requests").select("*").eq("id", id).single();
      if (!cr) throw new Error("Request not found");
      if (cr.status !== "pending") throw new Error(`Already ${cr.status}`);
      if (action === "approve") {
        if (Number(cr.amount_paid) < Number(cr.package_amount)) throw new Error("Underpaid — cannot approve");
        const { data: prof } = await supabase.from("profiles").select("wallet_points").eq("user_id", cr.user_id).single();
        const newPts = (prof?.wallet_points || 0) + Number(cr.package_amount);
        await supabase.from("profiles").update({ wallet_points: newPts }).eq("user_id", cr.user_id);
        await supabase.from("credit_requests").update({ status: "approved" }).eq("id", id);
        await supabase.from("transactions").insert({
          user_id: cr.user_id, amount: Number(cr.package_amount), type: "credit_topup",
          description: `Credit approved via Telegram (${cr.transaction_code || cr.order_id || id})`,
        });
        resultMsg = "✅ Approved & credit added";
      } else {
        await supabase.from("credit_requests").update({ status: "rejected" }).eq("id", id);
        resultMsg = "❌ Rejected";
      }
    } else if (kind === "topup") {
      const newStatus = action === "approve" ? "approved" : "rejected";
      await supabase.from("topup_requests").update({ status: newStatus }).eq("id", id);
      resultMsg = action === "approve" ? "✅ Topup approved" : "❌ Topup rejected";
    } else if (kind === "purchase") {
      resultMsg = action === "approve" ? "✅ Acknowledged" : "❌ Flagged";
    }

    await tg("editMessageText", {
      chat_id: chatId, message_id: msgId,
      text: cb.message.text + `\n\n— ${resultMsg}`,
    });
    await tg("answerCallbackQuery", { callback_query_id: cb.id, text: resultMsg });
  } catch (e) {
    await tg("answerCallbackQuery", { callback_query_id: cb.id, text: String(e), show_alert: true });
  }
}

Deno.serve(async () => {
  const start = Date.now();
  const { data: state } = await supabase.from("telegram_bot_state").select("update_offset").eq("id", 1).single();
  let offset = state?.update_offset || 0;
  let processed = 0;

  while (Date.now() - start < MAX_RUNTIME) {
    const remaining = MAX_RUNTIME - (Date.now() - start);
    const timeout = Math.min(45, Math.floor(remaining / 1000) - 5);
    if (timeout < 1) break;
    const r = await fetch(`${TG}/getUpdates`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ offset, timeout, allowed_updates: ["message", "callback_query"] }),
    });
    const data = await r.json();
    if (!data.ok) break;
    const updates = data.result || [];
    if (updates.length === 0) continue;

    for (const u of updates) {
      try {
        if (u.message) await handleMessage(u.message);
        if (u.callback_query) await handleCallback(u.callback_query);
      } catch (e) {
        console.error("update error", e);
      }
      processed++;
    }
    offset = Math.max(...updates.map((u: any) => u.update_id)) + 1;
    await supabase.from("telegram_bot_state").update({ update_offset: offset, updated_at: new Date().toISOString() }).eq("id", 1);
  }

  return new Response(JSON.stringify({ ok: true, processed, offset }), {
    headers: { "Content-Type": "application/json" },
  });
});
