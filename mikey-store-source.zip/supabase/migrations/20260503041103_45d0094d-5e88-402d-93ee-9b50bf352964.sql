
-- Telegram link: gmail <-> telegram chat
CREATE TABLE public.telegram_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  telegram_chat_id bigint NOT NULL UNIQUE,
  telegram_username text,
  verified_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.telegram_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own telegram link" ON public.telegram_links FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins manage telegram links" ON public.telegram_links FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- One-time login OTPs created by the bot
CREATE TABLE public.telegram_otps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  telegram_chat_id bigint NOT NULL,
  used boolean NOT NULL DEFAULT false,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '10 minutes'),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_telegram_otps_email_code ON public.telegram_otps(email, code) WHERE used = false;
ALTER TABLE public.telegram_otps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins manage otps" ON public.telegram_otps FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- Bot polling state
CREATE TABLE public.telegram_bot_state (
  id int PRIMARY KEY CHECK (id = 1),
  update_offset bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.telegram_bot_state (id, update_offset) VALUES (1, 0);
ALTER TABLE public.telegram_bot_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view bot state" ON public.telegram_bot_state FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'));

-- Per-product user-id requirement
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS require_user_id boolean NOT NULL DEFAULT false;
ALTER TABLE public.topup_packages ADD COLUMN IF NOT EXISTS require_user_id boolean NOT NULL DEFAULT true;

-- Notified flags so we don't double-notify
ALTER TABLE public.credit_requests ADD COLUMN IF NOT EXISTS notified_at timestamptz;
ALTER TABLE public.topup_requests ADD COLUMN IF NOT EXISTS notified_at timestamptz;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS notified_at timestamptz;

-- pg_cron + pg_net for bot polling
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;
