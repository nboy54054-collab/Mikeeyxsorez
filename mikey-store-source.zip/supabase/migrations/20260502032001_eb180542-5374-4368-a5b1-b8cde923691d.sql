-- Add fake_stock per product (jsonb keyed by duration)
ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS fake_stock jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Seed global toggle for fake stock visibility
INSERT INTO public.site_settings (key, value)
VALUES ('fake_stock_enabled', 'false')
ON CONFLICT (key) DO NOTHING;