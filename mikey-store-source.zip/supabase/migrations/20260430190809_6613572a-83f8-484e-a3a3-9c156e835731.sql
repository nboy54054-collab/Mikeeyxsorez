-- Create role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- User roles table
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

-- Profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    email TEXT NOT NULL,
    display_name TEXT,
    wallet_points INTEGER NOT NULL DEFAULT 0,
    total_purchases INTEGER NOT NULL DEFAULT 0,
    is_banned BOOLEAN NOT NULL DEFAULT false,
    is_approved boolean NOT NULL DEFAULT false,
    photo_url text,
    phone_number text,
    whatsapp_number text,
    discord_link text,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Products table
CREATE TABLE public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    price_points INTEGER NOT NULL,
    price_usd numeric DEFAULT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    duration_days integer[] DEFAULT '{30}',
    duration_prices jsonb DEFAULT '{}',
    tier_prices jsonb NOT NULL DEFAULT '{}'::jsonb,
    file_url text,
    image_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Keys table
CREATE TABLE public.keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE NOT NULL,
    key_code TEXT NOT NULL,
    is_used BOOLEAN NOT NULL DEFAULT false,
    used_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    used_at TIMESTAMPTZ,
    duration_days integer DEFAULT 30,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.keys ENABLE ROW LEVEL SECURITY;

-- Transactions table
CREATE TABLE public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('point_added', 'point_deducted', 'purchase', 'admin_edit')),
    amount INTEGER NOT NULL DEFAULT 0,
    description TEXT,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    key_id UUID REFERENCES public.keys(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (user_id, email)
    VALUES (NEW.id, NEW.email);
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies
CREATE POLICY "Users can view own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all roles" ON public.user_roles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update all profiles" ON public.profiles FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Anyone can view products" ON public.products FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage products" ON public.products FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage keys" ON public.keys FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users can view own keys" ON public.keys FOR SELECT TO authenticated USING (used_by = auth.uid());
CREATE POLICY "Anyone authenticated can view unused keys" ON public.keys FOR SELECT TO authenticated USING (is_used = false);

CREATE POLICY "Users can view own transactions" ON public.transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all transactions" ON public.transactions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can insert transactions" ON public.transactions FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('product-files', 'product-files', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('logo-media', 'logo-media', true) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('payment-proofs', 'payment-proofs', false) ON CONFLICT (id) DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('topup-qr', 'topup-qr', true) ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Anyone can view product files" ON storage.objects FOR SELECT USING (bucket_id = 'product-files');
CREATE POLICY "Admins can upload product files" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'product-files' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete product files" ON storage.objects FOR DELETE USING (bucket_id = 'product-files' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view avatars" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "Users can upload own avatar" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update own avatar" ON storage.objects FOR UPDATE USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Anyone can view logo media" ON storage.objects FOR SELECT USING (bucket_id = 'logo-media');
CREATE POLICY "Admins can manage logo media" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'logo-media' AND has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can delete logo media" ON storage.objects FOR DELETE USING (bucket_id = 'logo-media' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can upload payment proofs" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'payment-proofs');
CREATE POLICY "Admins can view payment proofs" ON storage.objects FOR SELECT USING (bucket_id = 'payment-proofs' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Anyone can view topup qr" ON storage.objects FOR SELECT USING (bucket_id = 'topup-qr');
CREATE POLICY "Admins can manage topup qr" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'topup-qr' AND has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can update topup qr" ON storage.objects FOR UPDATE USING (bucket_id = 'topup-qr' AND has_role(auth.uid(), 'admin'::app_role));

-- Site settings
CREATE TABLE public.site_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key text NOT NULL UNIQUE,
  value text,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view settings" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Admins can manage settings" ON public.site_settings FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

INSERT INTO public.site_settings (key, value) VALUES
  ('whatsapp_link', ''),
  ('tiktok_link', ''),
  ('discord_link', ''),
  ('maintenance_mode', 'false'),
  ('topup_payment_method', 'qr'),
  ('topup_processing_time', '5-30 minutes'),
  ('topup_qr_url', ''),
  ('require_approval', 'true'),
  ('esewa_qr_url', NULL),
  ('khalti_qr_url', NULL),
  ('bank_qr_url', NULL),
  ('topup_notification_email', 'asminchy79@gmail.com'),
  ('chat_welcome_message', 'Welcome! 👋 How can we help you today?'),
  ('chat_response_time', '5-15 minutes'),
  ('chat_enabled', 'true'),
  ('topup_enabled', 'true'),
  ('reseller_benefits_text', E'💰 Extra Discount on Bulk Purchases\n🔑 Free Keys on Selected Plans\n⚡ Instant Delivery & Fast Access\n🛡️ 100% Safe & Secure System\n📈 High Profit Margin\n🎯 Priority Support for Resellers\n💎 Limited Time Bonus')
ON CONFLICT (key) DO NOTHING;

-- Offers
CREATE TABLE public.offers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL DEFAULT 'offer',
  price_points INTEGER,
  duration_days INTEGER,
  key_code TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage offers" ON public.offers FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Anyone can view active offers" ON public.offers FOR SELECT USING (is_active = true);
CREATE TRIGGER update_offers_updated_at BEFORE UPDATE ON public.offers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Topup tables
CREATE TABLE public.topup_servers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  flag text DEFAULT '🌐',
  logo_url text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.topup_servers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage topup servers" ON public.topup_servers FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Anyone can view active topup servers" ON public.topup_servers FOR SELECT USING (is_active = true);

CREATE TABLE public.topup_games (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  image_url text,
  emoji text DEFAULT '🎮',
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer DEFAULT 0,
  uid_label text DEFAULT 'Game UID',
  id_label text DEFAULT 'Player ID',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.topup_games ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage topup games" ON public.topup_games FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Anyone can view active topup games" ON public.topup_games FOR SELECT USING (is_active = true);

CREATE TABLE public.topup_packages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT NOT NULL,
  price NUMERIC NOT NULL DEFAULT 0,
  duration_days INTEGER,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  image_url text,
  description text,
  game_id uuid REFERENCES public.topup_games(id) ON DELETE SET NULL,
  diamonds integer,
  emoji text DEFAULT '💎',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.topup_packages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active topup packages" ON public.topup_packages FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can manage topup packages" ON public.topup_packages FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER update_topup_packages_updated_at BEFORE UPDATE ON public.topup_packages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.topup_packages (label, price, duration_days, sort_order) VALUES
  ('Weekly Lite', 50, 3, 1),
  ('Weekly', 100, 7, 2),
  ('Monthly', 300, 30, 3);

CREATE TABLE public.topup_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  game_uid TEXT NOT NULL,
  product_name TEXT NOT NULL,
  duration_label TEXT NOT NULL,
  amount_paid NUMERIC NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'qr',
  payment_proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  fake_score INTEGER DEFAULT 0,
  admin_note TEXT,
  server_id uuid REFERENCES public.topup_servers(id) ON DELETE SET NULL,
  server_name text,
  game_name text DEFAULT 'Unknown',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.topup_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can insert topup requests" ON public.topup_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can view all topup requests" ON public.topup_requests FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can update topup requests" ON public.topup_requests FOR UPDATE USING (has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER update_topup_requests_updated_at BEFORE UPDATE ON public.topup_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.topup_admins (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  email text NOT NULL,
  added_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);
ALTER TABLE public.topup_admins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Main admins can manage topup admins" ON public.topup_admins FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Topup admins can view own record" ON public.topup_admins FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Topup admins can view topup requests" ON public.topup_requests FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.topup_admins WHERE topup_admins.user_id = auth.uid())
);
CREATE POLICY "Topup admins can update topup requests status" ON public.topup_requests FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.topup_admins WHERE topup_admins.user_id = auth.uid())
);

ALTER PUBLICATION supabase_realtime ADD TABLE public.topup_requests;

CREATE TABLE public.topup_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  game_name text,
  game_uid text,
  player_name text,
  server_name text,
  package_label text,
  package_price numeric DEFAULT 0,
  payment_method text,
  status text DEFAULT 'draft',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.topup_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own topup history" ON public.topup_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own topup history" ON public.topup_history FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own topup history" ON public.topup_history FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all topup history" ON public.topup_history FOR SELECT USING (has_role(auth.uid(), 'admin'::app_role));

-- Chat
CREATE TABLE public.chat_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  user_email text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own chat sessions" ON public.chat_sessions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create chat sessions" ON public.chat_sessions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can view all chat sessions" ON public.chat_sessions FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TABLE public.chat_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id uuid NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  sender_role text NOT NULL DEFAULT 'user',
  sender_id uuid,
  content text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view messages in own sessions" ON public.chat_messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.chat_sessions WHERE id = chat_messages.session_id AND user_id = auth.uid())
);
CREATE POLICY "Users can send messages in own sessions" ON public.chat_messages FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.chat_sessions WHERE id = chat_messages.session_id AND user_id = auth.uid())
);
CREATE POLICY "Admins can manage all messages" ON public.chat_messages FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_sessions;

-- Credit packages and requests
CREATE TABLE public.credit_packages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  amount NUMERIC NOT NULL DEFAULT 0,
  price NUMERIC NOT NULL DEFAULT 0,
  description TEXT,
  image_url TEXT,
  qr_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.credit_packages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active credit packages" ON public.credit_packages FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can manage credit packages" ON public.credit_packages FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.credit_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  package_id UUID REFERENCES public.credit_packages(id),
  package_amount NUMERIC NOT NULL DEFAULT 0,
  amount_paid NUMERIC NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'qr',
  payment_proof_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_note TEXT,
  transaction_code text,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.credit_requests ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_credit_requests_transaction_code ON public.credit_requests (transaction_code);

CREATE POLICY "Users can view own credit requests" ON public.credit_requests FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can create credit requests" ON public.credit_requests FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can view all credit requests" ON public.credit_requests FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update credit requests" ON public.credit_requests FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage credit packages full" ON public.credit_requests FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_credit_packages_updated_at BEFORE UPDATE ON public.credit_packages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_credit_requests_updated_at BEFORE UPDATE ON public.credit_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Reseller
CREATE TABLE public.reseller_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  seller_name TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  tiktok_channel TEXT,
  avg_followers TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  admin_note TEXT,
  reseller_tier text NOT NULL DEFAULT 'basic',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.reseller_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can create own application" ON public.reseller_applications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can view own application" ON public.reseller_applications FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage all applications" ON public.reseller_applications FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER update_reseller_applications_updated_at BEFORE UPDATE ON public.reseller_applications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.reseller_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price_credits NUMERIC NOT NULL DEFAULT 0,
  duration_days INTEGER[] DEFAULT '{30}'::integer[],
  duration_prices JSONB DEFAULT '{}'::jsonb,
  stock INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.reseller_products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage reseller products" ON public.reseller_products FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Approved resellers can view active products" ON public.reseller_products FOR SELECT TO authenticated USING (
  is_active = true AND EXISTS (SELECT 1 FROM public.reseller_applications WHERE user_id = auth.uid() AND status = 'approved')
);
CREATE TRIGGER update_reseller_products_updated_at BEFORE UPDATE ON public.reseller_products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.reseller_keys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key_code TEXT NOT NULL,
  product_id UUID NOT NULL REFERENCES public.reseller_products(id) ON DELETE CASCADE,
  duration_days INTEGER DEFAULT 30,
  is_used BOOLEAN NOT NULL DEFAULT false,
  used_by UUID,
  used_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
ALTER TABLE public.reseller_keys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage reseller keys" ON public.reseller_keys FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Approved resellers can view own keys" ON public.reseller_keys FOR SELECT TO authenticated USING (used_by = auth.uid());

-- Payment methods
CREATE TABLE public.payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  method_type text NOT NULL DEFAULT 'qr',
  currency text DEFAULT 'USD',
  qr_url text,
  instructions text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active payment methods" ON public.payment_methods FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can manage payment methods" ON public.payment_methods FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON public.payment_methods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Bonus rules
CREATE TABLE public.bonus_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  min_keys INTEGER NOT NULL,
  free_keys INTEGER NOT NULL,
  product_id UUID NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bonus_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active bonus rules" ON public.bonus_rules FOR SELECT USING (is_active = true);
CREATE POLICY "Admins can manage bonus rules" ON public.bonus_rules FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE TRIGGER update_bonus_rules_updated_at BEFORE UPDATE ON public.bonus_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();