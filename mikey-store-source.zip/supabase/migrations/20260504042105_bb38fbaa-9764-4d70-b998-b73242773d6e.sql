
-- 1. access_codes table
CREATE TABLE IF NOT EXISTS public.access_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  scope text NOT NULL CHECK (scope IN ('credit','topup')),
  email text NOT NULL,
  used boolean NOT NULL DEFAULT false,
  used_at timestamptz,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '24 hours'),
  issued_by uuid,
  issued_via text NOT NULL DEFAULT 'admin',
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_access_codes_email ON public.access_codes(email);
CREATE INDEX IF NOT EXISTS idx_access_codes_code ON public.access_codes(code);

ALTER TABLE public.access_codes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins manage access codes" ON public.access_codes;
CREATE POLICY "Admins manage access codes" ON public.access_codes
FOR ALL TO authenticated
USING (public.has_role(auth.uid(),'admin'))
WITH CHECK (public.has_role(auth.uid(),'admin'));

-- 2. profiles.access_scope
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS access_scope text;

-- 3. topup_packages additions
ALTER TABLE public.topup_packages ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'topup';
ALTER TABLE public.topup_packages ADD COLUMN IF NOT EXISTS fields jsonb NOT NULL DEFAULT '[]'::jsonb;

-- 4. products additions
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS fields jsonb NOT NULL DEFAULT '[]'::jsonb;

-- 5. Cross-table transaction-code uniqueness triggers
CREATE OR REPLACE FUNCTION public.reject_cross_duplicate_code()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.transaction_code IS NULL OR NEW.status <> 'pending' THEN
    RETURN NEW;
  END IF;

  IF TG_TABLE_NAME = 'credit_requests' THEN
    IF EXISTS (SELECT 1 FROM public.topup_requests
               WHERE transaction_code = NEW.transaction_code
                 AND status IN ('approved','pending')) THEN
      NEW.status := 'rejected';
      NEW.admin_note := COALESCE(NEW.admin_note,'') || ' [Auto-rejected: code already used in topup]';
    END IF;
  ELSIF TG_TABLE_NAME = 'topup_requests' THEN
    IF EXISTS (SELECT 1 FROM public.credit_requests
               WHERE transaction_code = NEW.transaction_code
                 AND status IN ('approved','pending')) THEN
      NEW.status := 'rejected';
      NEW.admin_note := COALESCE(NEW.admin_note,'') || ' [Auto-rejected: code already used in credit]';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_credit_cross_dup ON public.credit_requests;
CREATE TRIGGER trg_credit_cross_dup BEFORE INSERT ON public.credit_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_cross_duplicate_code();

DROP TRIGGER IF EXISTS trg_topup_cross_dup ON public.topup_requests;
CREATE TRIGGER trg_topup_cross_dup BEFORE INSERT ON public.topup_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_cross_duplicate_code();

-- Wire existing same-table duplicate triggers (if not already)
DROP TRIGGER IF EXISTS trg_credit_dup ON public.credit_requests;
CREATE TRIGGER trg_credit_dup BEFORE INSERT ON public.credit_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_duplicate_credit_code();

DROP TRIGGER IF EXISTS trg_topup_dup ON public.topup_requests;
CREATE TRIGGER trg_topup_dup BEFORE INSERT ON public.topup_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_duplicate_topup_code();
