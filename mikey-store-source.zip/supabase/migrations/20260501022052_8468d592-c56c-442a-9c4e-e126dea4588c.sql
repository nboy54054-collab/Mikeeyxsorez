
-- 1. payment_methods enhancements
ALTER TABLE public.payment_methods 
  ADD COLUMN IF NOT EXISTS payment_id text,
  ADD COLUMN IF NOT EXISTS display_field text NOT NULL DEFAULT 'qr';
-- display_field: 'qr' | 'id' | 'both'

-- 2. product <-> payment_methods mapping
CREATE TABLE IF NOT EXISTS public.product_payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL,
  payment_method_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(product_id, payment_method_id)
);
ALTER TABLE public.product_payment_methods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage product payment methods"
ON public.product_payment_methods FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone authenticated can view product payment methods"
ON public.product_payment_methods FOR SELECT TO authenticated
USING (true);

-- 3. credit_requests: order_id + expires_at
ALTER TABLE public.credit_requests
  ADD COLUMN IF NOT EXISTS order_id text UNIQUE,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS payment_method_id uuid;
ALTER TABLE public.credit_requests ALTER COLUMN payment_proof_url DROP NOT NULL;

-- 4. topup_requests: order_id + expires_at
ALTER TABLE public.topup_requests
  ADD COLUMN IF NOT EXISTS order_id text UNIQUE,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS transaction_code text;
ALTER TABLE public.topup_requests ALTER COLUMN payment_proof_url DROP NOT NULL;

-- 5. coupons (products only)
CREATE TABLE IF NOT EXISTS public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  discount_percent numeric,
  discount_amount numeric,
  max_uses integer,           -- NULL = unlimited
  used_count integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage coupons" ON public.coupons FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone authenticated can view active coupons"
ON public.coupons FOR SELECT TO authenticated
USING (is_active = true);

CREATE TABLE IF NOT EXISTS public.coupon_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid NOT NULL,
  user_id uuid NOT NULL,
  used_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.coupon_redemptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins view all redemptions" ON public.coupon_redemptions FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Users view own redemptions" ON public.coupon_redemptions FOR SELECT TO authenticated
USING (auth.uid() = user_id);
CREATE POLICY "Users insert own redemptions" ON public.coupon_redemptions FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 6. key_orders (out of stock requests)
CREATE TABLE IF NOT EXISTS public.key_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL,
  duration_days integer NOT NULL DEFAULT 30,
  quantity integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'pending', -- pending | fulfilled | rejected
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.key_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage key orders" ON public.key_orders FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "Users insert own key orders" ON public.key_orders FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users view own key orders" ON public.key_orders FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- 7. Auto-reject duplicate transaction codes (credit_requests)
CREATE OR REPLACE FUNCTION public.reject_duplicate_credit_code()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.transaction_code IS NOT NULL AND NEW.status = 'pending' THEN
    IF EXISTS (
      SELECT 1 FROM public.credit_requests
      WHERE transaction_code = NEW.transaction_code
        AND id <> NEW.id
        AND status IN ('approved','pending')
    ) THEN
      NEW.status := 'rejected';
      NEW.admin_note := COALESCE(NEW.admin_note,'') || ' [Auto-rejected: duplicate transaction code]';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_reject_dup_credit ON public.credit_requests;
CREATE TRIGGER trg_reject_dup_credit
BEFORE INSERT ON public.credit_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_duplicate_credit_code();

-- Same for topup_requests
CREATE OR REPLACE FUNCTION public.reject_duplicate_topup_code()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.transaction_code IS NOT NULL AND NEW.status = 'pending' THEN
    IF EXISTS (
      SELECT 1 FROM public.topup_requests
      WHERE transaction_code = NEW.transaction_code
        AND id <> NEW.id
        AND status IN ('approved','pending')
    ) THEN
      NEW.status := 'rejected';
      NEW.admin_note := COALESCE(NEW.admin_note,'') || ' [Auto-rejected: duplicate transaction code]';
    END IF;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_reject_dup_topup ON public.topup_requests;
CREATE TRIGGER trg_reject_dup_topup
BEFORE INSERT ON public.topup_requests
FOR EACH ROW EXECUTE FUNCTION public.reject_duplicate_topup_code();

-- 8. Order ID generator function
CREATE OR REPLACE FUNCTION public.generate_order_id()
RETURNS text LANGUAGE plpgsql AS $$
DECLARE
  new_id text;
BEGIN
  new_id := 'ORD-' || to_char(now(),'YYMMDD') || '-' || upper(substring(replace(gen_random_uuid()::text,'-',''),1,6));
  RETURN new_id;
END $$;

-- 9. Default site settings
INSERT INTO public.site_settings (key, value) VALUES
  ('currency','USD'),
  ('currency_symbol','$'),
  ('npr_rate','133'),
  ('approval_time_minutes','5')
ON CONFLICT (key) DO NOTHING;

-- 10. updated_at triggers
CREATE TRIGGER update_coupons_updated_at BEFORE UPDATE ON public.coupons
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_key_orders_updated_at BEFORE UPDATE ON public.key_orders
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
