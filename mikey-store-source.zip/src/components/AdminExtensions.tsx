import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Trash2, Tag, DollarSign, Package, CheckCircle, X } from "lucide-react";
import { refreshCurrency } from "@/hooks/useCurrency";

/* ---------- Currency settings ---------- */
export const AdminCurrencySettings = () => {
  const [code, setCode] = useState<"USD" | "NPR">("USD");
  const [rate, setRate] = useState("133");
  const [approvalMin, setApprovalMin] = useState("5");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("site_settings").select("key,value")
      .in("key", ["currency", "npr_rate", "approval_time_minutes"])
      .then(({ data }) => {
        const m: Record<string, string> = {};
        (data || []).forEach((r: any) => (m[r.key] = r.value || ""));
        setCode((m.currency === "NPR" ? "NPR" : "USD"));
        setRate(m.npr_rate || "133");
        setApprovalMin(m.approval_time_minutes || "5");
        setLoading(false);
      });
  }, []);

  const save = async () => {
    await Promise.all([
      supabase.from("site_settings").upsert({ key: "currency", value: code }, { onConflict: "key" }),
      supabase.from("site_settings").upsert({ key: "currency_symbol", value: code === "NPR" ? "रु" : "$" }, { onConflict: "key" }),
      supabase.from("site_settings").upsert({ key: "npr_rate", value: rate }, { onConflict: "key" }),
      supabase.from("site_settings").upsert({ key: "approval_time_minutes", value: approvalMin }, { onConflict: "key" }),
    ]);
    await refreshCurrency();
    toast.success("Saved!");
  };

  if (loading) return null;
  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 space-y-3">
        <h3 className="font-bold flex items-center gap-2 text-sm">
          <DollarSign className="w-4 h-4 text-primary" /> Wallet Currency
        </h3>
        <p className="text-[11px] text-muted-foreground">
          Switch how credits show to users. Stored prices stay in USD; NPR uses rate below.
        </p>
        <div className="flex gap-2">
          <Button size="sm" variant={code === "USD" ? "default" : "outline"} onClick={() => setCode("USD")}>USD ($)</Button>
          <Button size="sm" variant={code === "NPR" ? "default" : "outline"} onClick={() => setCode("NPR")}>NPR (रु)</Button>
        </div>
        <div>
          <label className="text-[11px] text-muted-foreground">NPR rate (1 USD = ?)</label>
          <Input value={rate} onChange={(e) => setRate(e.target.value)} type="number" className="h-8 text-sm" />
        </div>
        <div>
          <label className="text-[11px] text-muted-foreground">Approval time message (minutes)</label>
          <Input value={approvalMin} onChange={(e) => setApprovalMin(e.target.value)} type="number" className="h-8 text-sm" />
          <p className="text-[10px] text-muted-foreground mt-1">Shown to users as expected approval window.</p>
        </div>
        <Button size="sm" onClick={save} className="w-full">Save</Button>
      </CardContent>
    </Card>
  );
};

/* ---------- Coupons ---------- */
export const AdminCoupons = () => {
  const [list, setList] = useState<any[]>([]);
  const [dialog, setDialog] = useState(false);
  const [form, setForm] = useState({
    code: "",
    discount_percent: "",
    discount_amount: "",
    max_uses: "",
    is_active: true,
    note: "",
  });

  const fetchAll = async () => {
    const { data } = await supabase.from("coupons" as any).select("*").order("created_at", { ascending: false });
    setList(data || []);
  };
  useEffect(() => { fetchAll(); }, []);

  const save = async () => {
    if (!form.code.trim()) return toast.error("Code required");
    const payload: any = {
      code: form.code.trim().toUpperCase(),
      discount_percent: form.discount_percent ? Number(form.discount_percent) : null,
      discount_amount: form.discount_amount ? Number(form.discount_amount) : null,
      max_uses: form.max_uses ? Number(form.max_uses) : null,
      is_active: form.is_active,
      note: form.note,
    };
    const { error } = await supabase.from("coupons" as any).insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Coupon created");
    setDialog(false);
    setForm({ code: "", discount_percent: "", discount_amount: "", max_uses: "", is_active: true, note: "" });
    fetchAll();
  };

  const toggle = async (c: any) => {
    await supabase.from("coupons" as any).update({ is_active: !c.is_active }).eq("id", c.id);
    fetchAll();
  };
  const remove = async (id: string) => {
    await supabase.from("coupons" as any).delete().eq("id", id);
    fetchAll();
  };

  return (
    <>
      <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
        <CardContent className="p-4 space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="font-bold flex items-center gap-2 text-sm">
              <Tag className="w-4 h-4 text-primary" /> Discount Coupons (Products)
            </h3>
            <Button size="sm" onClick={() => setDialog(true)}><Plus className="w-3 h-3 mr-1" />New</Button>
          </div>
          {list.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-3">No coupons yet.</p>
          )}
          {list.map((c) => (
            <div key={c.id} className="flex items-center justify-between p-2.5 bg-background/50 rounded border border-border/30">
              <div className="text-xs space-y-0.5">
                <p className="font-mono font-bold text-sm">{c.code}</p>
                <p className="text-muted-foreground">
                  {c.discount_percent ? `${c.discount_percent}% off` : `$${c.discount_amount} off`}
                  {" · "}
                  {c.max_uses == null ? "Unlimited" : `${c.used_count}/${c.max_uses} used`}
                </p>
                {c.note && <p className="text-[10px] text-muted-foreground">{c.note}</p>}
              </div>
              <div className="flex items-center gap-1">
                <Badge variant={c.is_active ? "default" : "secondary"} className="text-[10px]">
                  {c.is_active ? "Active" : "Off"}
                </Badge>
                <Button size="icon" variant="ghost" onClick={() => toggle(c)}><CheckCircle className="w-3 h-3" /></Button>
                <Button size="icon" variant="ghost" className="text-destructive" onClick={() => remove(c.id)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>New Coupon</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs">Code</label>
              <Input value={form.code} onChange={(e) => setForm((s) => ({ ...s, code: e.target.value }))} placeholder="SAVE20" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs">Discount %</label>
                <Input type="number" value={form.discount_percent} onChange={(e) => setForm((s) => ({ ...s, discount_percent: e.target.value, discount_amount: "" }))} placeholder="20" />
              </div>
              <div>
                <label className="text-xs">OR Discount $</label>
                <Input type="number" value={form.discount_amount} onChange={(e) => setForm((s) => ({ ...s, discount_amount: e.target.value, discount_percent: "" }))} placeholder="5" />
              </div>
            </div>
            <div>
              <label className="text-xs">Max uses (blank = unlimited)</label>
              <Input type="number" value={form.max_uses} onChange={(e) => setForm((s) => ({ ...s, max_uses: e.target.value }))} placeholder="100" />
            </div>
            <div>
              <label className="text-xs">Note (internal)</label>
              <Input value={form.note} onChange={(e) => setForm((s) => ({ ...s, note: e.target.value }))} placeholder="e.g. influencer XYZ" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(false)}>Cancel</Button>
            <Button onClick={save}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

/* ---------- Key Orders (out-of-stock requests) ---------- */
export const AdminKeyOrders = () => {
  const [list, setList] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<Record<string, any>>({});

  const fetchAll = async () => {
    const { data: orders } = await supabase.from("key_orders" as any)
      .select("*").order("created_at", { ascending: false });
    setList(orders || []);
    const { data: prods } = await supabase.from("products").select("id,name");
    setProducts(prods || []);
    if (orders && orders.length) {
      const ids = [...new Set(orders.map((o: any) => o.user_id))];
      const { data: profs } = await supabase.from("profiles").select("user_id,email,display_name").in("user_id", ids);
      const map: Record<string, any> = {};
      (profs || []).forEach((p: any) => (map[p.user_id] = p));
      setProfiles(map);
    }
  };
  useEffect(() => { fetchAll(); }, []);

  const fulfill = async (o: any) => {
    // Mark fulfilled — admin will manually add a key for this user via Admin Keys panel
    await supabase.from("key_orders" as any).update({ status: "fulfilled" }).eq("id", o.id);
    toast.success("Marked fulfilled. Now add the keys to that user from Keys section.");
    fetchAll();
  };
  const reject = async (o: any) => {
    await supabase.from("key_orders" as any).update({ status: "rejected" }).eq("id", o.id);
    fetchAll();
  };

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 space-y-3">
        <h3 className="font-bold flex items-center gap-2 text-sm">
          <Package className="w-4 h-4 text-primary" /> Pre-Orders (out-of-stock requests)
        </h3>
        {list.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-3">No pre-orders.</p>
        )}
        {list.map((o) => {
          const prod = products.find((p) => p.id === o.product_id);
          const prof = profiles[o.user_id];
          return (
            <div key={o.id} className="p-2.5 bg-background/50 rounded border border-border/30 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <p className="font-semibold">{prod?.name || "Product"} · {o.duration_days}d × {o.quantity}</p>
                <Badge variant={o.status === "pending" ? "secondary" : o.status === "fulfilled" ? "default" : "destructive"} className="text-[10px]">
                  {o.status}
                </Badge>
              </div>
              <p className="text-muted-foreground">
                {prof?.email || o.user_id} · {new Date(o.created_at).toLocaleString()}
              </p>
              {o.status === "pending" && (
                <div className="flex gap-1 pt-1">
                  <Button size="sm" variant="outline" className="h-7 text-xs flex-1" onClick={() => fulfill(o)}>
                    <CheckCircle className="w-3 h-3 mr-1" /> Mark Fulfilled
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs text-destructive" onClick={() => reject(o)}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

/* ---------- Per-product Payment Methods mapping ---------- */
export const AdminProductPaymentMethods = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [methods, setMethods] = useState<any[]>([]);
  const [mapping, setMapping] = useState<Record<string, string[]>>({}); // product_id -> [method_id]
  const [activeProd, setActiveProd] = useState<string>("");

  const fetchAll = async () => {
    const [{ data: prods }, { data: ms }, { data: links }] = await Promise.all([
      supabase.from("products").select("id,name").order("name"),
      supabase.from("payment_methods" as any).select("id,name,is_active"),
      supabase.from("product_payment_methods" as any).select("product_id, payment_method_id"),
    ]);
    setProducts(prods || []);
    setMethods((ms || []).filter((m: any) => m.is_active));
    const map: Record<string, string[]> = {};
    (links || []).forEach((l: any) => {
      map[l.product_id] = map[l.product_id] || [];
      map[l.product_id].push(l.payment_method_id);
    });
    setMapping(map);
    if (prods && prods.length && !activeProd) setActiveProd(prods[0].id);
  };
  useEffect(() => { fetchAll(); }, []);

  const toggle = async (pid: string, mid: string) => {
    const has = mapping[pid]?.includes(mid);
    if (has) {
      await supabase.from("product_payment_methods" as any)
        .delete().eq("product_id", pid).eq("payment_method_id", mid);
    } else {
      await supabase.from("product_payment_methods" as any)
        .insert({ product_id: pid, payment_method_id: mid });
    }
    fetchAll();
  };

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 space-y-3">
        <h3 className="font-bold flex items-center gap-2 text-sm">
          <Package className="w-4 h-4 text-primary" /> Per-product Payment Methods
        </h3>
        <p className="text-[11px] text-muted-foreground">
          Pick which payment methods are allowed per product. If none picked, all active methods apply.
        </p>
        <select value={activeProd} onChange={(e) => setActiveProd(e.target.value)}
          className="w-full h-9 rounded-md border bg-background px-2 text-sm">
          {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <div className="space-y-1">
          {methods.length === 0 && <p className="text-xs text-muted-foreground">Add active payment methods first.</p>}
          {methods.map((m) => {
            const checked = !!mapping[activeProd]?.includes(m.id);
            return (
              <button key={m.id} onClick={() => toggle(activeProd, m.id)}
                className={`w-full flex items-center justify-between p-2 rounded border-2 text-xs ${
                  checked ? "border-primary bg-primary/10" : "border-border/50"
                }`}>
                <span>{m.name}</span>
                {checked && <CheckCircle className="w-3 h-3 text-primary" />}
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
