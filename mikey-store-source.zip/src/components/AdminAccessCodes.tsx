import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Copy, Trash2, Plus, KeyRound } from "lucide-react";

const AdminAccessCodes = () => {
  const [codes, setCodes] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [scope, setScope] = useState<"credit" | "topup">("credit");
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const { data } = await supabase.from("access_codes").select("*").order("created_at", { ascending: false }).limit(100);
    setCodes(data || []);
  };
  useEffect(() => { load(); }, []);

  const issue = async () => {
    if (!email.includes("@")) return toast.error("Valid Gmail required");
    setLoading(true);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const { error } = await supabase.from("access_codes").insert({
      code, scope, email: email.toLowerCase().trim(), issued_via: "admin",
    });
    if (error) toast.error(error.message);
    else {
      toast.success(`Code ${code} issued for ${email}`);
      setEmail("");
      load();
    }
    setLoading(false);
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this code?")) return;
    await supabase.from("access_codes").delete().eq("id", id);
    load();
  };

  const copy = (c: string) => { navigator.clipboard.writeText(c); toast.success("Copied"); };

  const statusOf = (c: any) => {
    if (c.used) return { label: "USED", color: "bg-gray-500" };
    if (new Date(c.expires_at) < new Date()) return { label: "EXPIRED", color: "bg-red-500" };
    return { label: "ACTIVE", color: "bg-green-500" };
  };

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <KeyRound className="text-yellow-500" />
        <h2 className="text-xl font-bold">One-Time Access Codes</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
        <div>
          <label className="text-xs text-muted-foreground">Gmail</label>
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="user@gmail.com" type="email" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Scope</label>
          <select value={scope} onChange={(e) => setScope(e.target.value as any)}
            className="w-full h-10 px-3 rounded-md border border-input bg-background">
            <option value="credit">Credit only</option>
            <option value="topup">Topup only</option>
          </select>
        </div>
        <Button onClick={issue} disabled={loading} className="bg-yellow-500 hover:bg-yellow-400 text-black">
          <Plus className="w-4 h-4 mr-1" /> Issue Code (24h)
        </Button>
      </div>

      <div className="space-y-2 max-h-[500px] overflow-y-auto">
        {codes.length === 0 && <p className="text-sm text-muted-foreground">No codes issued yet.</p>}
        {codes.map((c) => {
          const s = statusOf(c);
          return (
            <div key={c.id} className="flex items-center gap-3 p-3 rounded-lg border bg-card">
              <code className="font-mono text-lg font-bold tracking-wider">{c.code}</code>
              <Button size="icon" variant="ghost" onClick={() => copy(c.code)} className="h-7 w-7"><Copy className="w-3 h-3" /></Button>
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{c.email}</p>
                <p className="text-xs text-muted-foreground">
                  {c.scope.toUpperCase()} · via {c.issued_via} · {new Date(c.created_at).toLocaleString()}
                </p>
              </div>
              <Badge className={`${s.color} text-white`}>{s.label}</Badge>
              <Button size="icon" variant="ghost" onClick={() => remove(c.id)} className="h-7 w-7 text-red-500"><Trash2 className="w-3 h-3" /></Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

export default AdminAccessCodes;
