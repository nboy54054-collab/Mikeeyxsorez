import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Eye, Save, Sparkles } from "lucide-react";

export const AdminFakeStock = () => {
  const [enabled, setEnabled] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [drafts, setDrafts] = useState<Record<string, string>>({}); // duration -> string

  const loadAll = async () => {
    const [{ data: prods }, { data: setting }] = await Promise.all([
      supabase.from("products").select("id,name,duration_days,fake_stock").order("name"),
      supabase.from("site_settings").select("value").eq("key", "fake_stock_enabled").maybeSingle(),
    ]);
    setProducts(prods || []);
    setEnabled(setting?.value === "true");
    if (prods && prods.length && !activeId) setActiveId(prods[0].id);
  };
  useEffect(() => { loadAll(); }, []);

  useEffect(() => {
    const p = products.find((x) => x.id === activeId);
    if (!p) return;
    const fs = (p as any).fake_stock || {};
    const d: Record<string, string> = {};
    (p.duration_days || [30]).forEach((dd: number) => {
      d[String(dd)] = String(fs[String(dd)] ?? "");
    });
    setDrafts(d);
  }, [activeId, products]);

  const toggle = async (v: boolean) => {
    setEnabled(v);
    await supabase.from("site_settings").upsert(
      { key: "fake_stock_enabled", value: v ? "true" : "false" },
      { onConflict: "key" }
    );
    toast.success(v ? "Fake stock display ON" : "Fake stock display OFF");
  };

  const save = async () => {
    const p = products.find((x) => x.id === activeId);
    if (!p) return;
    const fs: Record<string, number> = {};
    Object.entries(drafts).forEach(([k, v]) => {
      const n = Number(v);
      if (v !== "" && !isNaN(n) && n > 0) fs[k] = n;
    });
    const { error } = await supabase.from("products").update({ fake_stock: fs as any }).eq("id", activeId);
    if (error) return toast.error(error.message);
    toast.success("Fake stock saved");
    loadAll();
  };

  const active = products.find((x) => x.id === activeId);

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold flex items-center gap-2 text-sm">
            <Sparkles className="w-4 h-4 text-primary" /> Fake Stock Display
          </h3>
          <div className="flex items-center gap-2">
            <Eye className="w-3 h-3 text-muted-foreground" />
            <Switch checked={enabled} onCheckedChange={toggle} />
          </div>
        </div>
        <p className="text-[11px] text-muted-foreground">
          Add fake stock numbers shown to users (added on top of real stock). Toggle above turns it on/off site-wide.
        </p>

        <div>
          <label className="text-[11px] text-muted-foreground">Product</label>
          <select
            value={activeId}
            onChange={(e) => setActiveId(e.target.value)}
            className="w-full h-9 rounded-md border bg-background px-2 text-sm"
          >
            {products.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        {active && (
          <div className="space-y-2">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">Per-duration fake count</p>
            {(active.duration_days || [30]).map((d: number) => (
              <div key={d} className="flex items-center gap-2">
                <span className="text-xs w-20">{d} days</span>
                <Input
                  type="number"
                  min="0"
                  placeholder="0"
                  className="h-8 text-sm"
                  value={drafts[String(d)] ?? ""}
                  onChange={(e) =>
                    setDrafts((s) => ({ ...s, [String(d)]: e.target.value }))
                  }
                />
              </div>
            ))}
            <Button size="sm" onClick={save} className="w-full mt-2">
              <Save className="w-3 h-3 mr-1" /> Save Fake Stock
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
