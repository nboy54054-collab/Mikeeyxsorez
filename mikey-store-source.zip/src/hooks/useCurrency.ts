import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface CurrencyConfig {
  code: "USD" | "NPR";
  symbol: string;
  rate: number; // NPR per 1 USD (used to convert stored USD prices)
}

let cached: CurrencyConfig | null = null;
const listeners = new Set<(c: CurrencyConfig) => void>();

async function load(): Promise<CurrencyConfig> {
  const { data } = await supabase
    .from("site_settings")
    .select("key,value")
    .in("key", ["currency", "currency_symbol", "npr_rate"]);
  const map: Record<string, string> = {};
  (data || []).forEach((r: any) => (map[r.key] = r.value || ""));
  const code = (map.currency === "NPR" ? "NPR" : "USD") as "USD" | "NPR";
  const symbol = map.currency_symbol || (code === "NPR" ? "रु" : "$");
  const rate = Number(map.npr_rate) || 133;
  cached = { code, symbol, rate };
  listeners.forEach((l) => l(cached!));
  return cached;
}

export function useCurrency(): CurrencyConfig & { format: (usd: number) => string } {
  const [c, setC] = useState<CurrencyConfig>(cached || { code: "USD", symbol: "$", rate: 133 });
  useEffect(() => {
    if (!cached) load().then(setC);
    const fn = (n: CurrencyConfig) => setC(n);
    listeners.add(fn);
    return () => { listeners.delete(fn); };
  }, []);
  const format = (usd: number) => {
    const n = Number(usd) || 0;
    if (c.code === "NPR") return `रु ${Math.round(n * c.rate).toLocaleString()}`;
    return `$${n.toFixed(2)}`;
  };
  return { ...c, format };
}

export async function refreshCurrency() {
  const next = await load();
  return next;
}
