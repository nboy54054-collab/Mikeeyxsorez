import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useCurrency } from "@/hooks/useCurrency";
import {
  Wallet, Plus, CheckCircle, Clock, QrCode, DollarSign, Copy, AlertTriangle, Hash,
} from "lucide-react";

const QUICK_AMOUNTS = [5, 10, 20, 50];
const ORDER_TTL_MIN = 15;

const BuyCredit = () => {
  const { user, profile } = useAuth();
  const { format, code: currencyCode, symbol } = useCurrency();

  const [amount, setAmount] = useState<string>("");
  const [methods, setMethods] = useState<any[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<any>(null);
  const [transactionCode, setTransactionCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [order, setOrder] = useState<any>(null); // active order awaiting tx code
  const [submitted, setSubmitted] = useState(false);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    supabase
      .from("payment_methods" as any)
      .select("*")
      .eq("is_active", true)
      .order("sort_order")
      .then(({ data }) => {
        setMethods(data || []);
        if (data && data.length > 0) setSelectedMethod(data[0]);
      });
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    supabase
      .from("credit_requests" as any)
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => setMyRequests(data || []));
  }, [user?.id, submitted]);

  // tick for countdown
  useEffect(() => {
    if (!order) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [order]);

  const remainingMs = order?.expires_at ? new Date(order.expires_at).getTime() - now : 0;
  const expired = order && remainingMs <= 0;

  // 1. Create order (reserves an order ID + 15-min window)
  const createOrder = async () => {
    const amt = Number(amount);
    if (!amt || amt < 1) return toast.error("Enter a valid amount (min $1)");
    if (amt > 5000) return toast.error("Max $5,000 per request");
    if (!selectedMethod) return toast.error("Select a payment method");
    if (!user) return toast.error("Sign in first");

    setSubmitting(true);
    try {
      const orderId = `ORD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const expiresAt = new Date(Date.now() + ORDER_TTL_MIN * 60 * 1000).toISOString();
      setOrder({
        order_id: orderId,
        amount: amt,
        method: selectedMethod,
        expires_at: expiresAt,
      });
    } catch (err: any) {
      toast.error(err.message || "Failed");
    }
    setSubmitting(false);
  };

  // 2. Submit transaction code
  const submitCode = async () => {
    if (!order) return;
    if (expired) return toast.error("Order expired. Please create a new one.");
    if (!transactionCode.trim()) return toast.error("Enter transaction code");
    if (transactionCode.trim().length < 4) return toast.error("Transaction code too short");

    setSubmitting(true);
    try {
      const { data, error } = await supabase
        .from("credit_requests" as any)
        .insert({
          user_id: user!.id,
          package_id: null,
          package_amount: order.amount,
          amount_paid: order.amount,
          payment_method: order.method.name,
          payment_method_id: order.method.id,
          transaction_code: transactionCode.trim(),
          order_id: order.order_id,
          expires_at: order.expires_at,
          status: "pending",
        })
        .select()
        .single();
      if (error) throw error;

      // Notify Telegram
      if ((data as any)?.id && (data as any)?.status === "pending") {
        supabase.functions.invoke("telegram-notify", {
          body: {
            kind: "credit",
            request_id: (data as any).id,
            email: user!.email,
            product: `Credit Top-up`,
            price: order.amount,
            transaction_code: transactionCode.trim(),
            extra: `Order: \`${order.order_id}\``,
          },
        }).catch(() => {});
      }

      // Trigger may have auto-rejected for duplicates
      if ((data as any)?.status === "rejected") {
        toast.error("This transaction code was already used. Auto-rejected.");
        setOrder(null);
        setTransactionCode("");
        setSubmitted(true);
        return;
      }

      setSubmitted(true);
      toast.success("Submitted! Admin will verify shortly. 🎉");
    } catch (err: any) {
      toast.error(err.message || "Failed to submit");
    }
    setSubmitting(false);
  };

  const reset = () => {
    setSubmitted(false);
    setOrder(null);
    setAmount("");
    setTransactionCode("");
  };

  const copy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied!");
  };

  // Submitted view
  if (submitted) {
    return (
      <DashboardLayout>
        <AnimatedBackground />
        <div className="relative z-10 max-w-md mx-auto pt-8 text-center space-y-3">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-16 h-16 mx-auto rounded-full bg-success/20 flex items-center justify-center"
          >
            <CheckCircle className="w-8 h-8 text-success" />
          </motion.div>
          <h1 className="text-xl font-bold">Request Submitted</h1>
          <p className="text-xs text-muted-foreground">
            Admin will verify your payment shortly.
          </p>
          <Button onClick={reset} size="sm" className="w-full">Add More Balance</Button>
        </div>
      </DashboardLayout>
    );
  }

  // Active order view (awaiting payment + tx code)
  if (order) {
    const mins = Math.max(0, Math.floor(remainingMs / 60000));
    const secs = Math.max(0, Math.floor((remainingMs % 60000) / 1000));
    const m = order.method;
    const showQR = (m.display_field === "qr" || m.display_field === "both") && m.qr_url;
    const showID = (m.display_field === "id" || m.display_field === "both") && m.payment_id;

    return (
      <DashboardLayout>
        <AnimatedBackground />
        <div className="relative z-10 max-w-md mx-auto space-y-3 pb-10">
          <Card className="border-primary/40 bg-card/70 backdrop-blur-md">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase text-muted-foreground tracking-wider">Order ID</p>
                  <button onClick={() => copy(order.order_id)} className="font-mono text-xs font-bold flex items-center gap-1 hover:text-primary">
                    {order.order_id} <Copy className="w-3 h-3" />
                  </button>
                </div>
                <Badge variant={expired ? "destructive" : "secondary"} className="text-[10px]">
                  <Clock className="w-3 h-3 mr-1" />
                  {expired ? "Expired" : `${mins}:${String(secs).padStart(2, "0")}`}
                </Badge>
              </div>

              <div className="bg-primary/10 rounded-lg p-3 text-center">
                <p className="text-[10px] uppercase text-muted-foreground">Pay this amount</p>
                <p className="text-2xl font-extrabold text-primary">{format(order.amount)}</p>
                {currencyCode === "NPR" && (
                  <p className="text-[10px] text-muted-foreground">≈ ${order.amount}</p>
                )}
              </div>

              <div className="text-center">
                <p className="text-[11px] font-semibold mb-2">Pay via {m.name}</p>
                {showQR && (
                  <img src={m.qr_url} alt="QR"
                    className="w-44 h-44 mx-auto rounded-lg border border-border/50 bg-white p-2 object-contain" />
                )}
                {showID && (
                  <div className="mt-2 flex items-center justify-center gap-1 bg-background/60 rounded-lg p-2">
                    <span className="text-[10px] text-muted-foreground">{m.name} ID:</span>
                    <button onClick={() => copy(m.payment_id)}
                      className="font-mono text-xs font-bold flex items-center gap-1 hover:text-primary">
                      {m.payment_id} <Copy className="w-3 h-3" />
                    </button>
                  </div>
                )}
                {m.instructions && (
                  <p className="text-[10px] text-muted-foreground mt-2 whitespace-pre-line">{m.instructions}</p>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-semibold uppercase text-muted-foreground flex items-center gap-1">
                  <Hash className="w-3 h-3" /> Transaction Code (after payment)
                </label>
                <Input
                  value={transactionCode}
                  onChange={(e) => setTransactionCode(e.target.value)}
                  placeholder="Paste transaction code here"
                  className="h-10 text-sm font-mono"
                  disabled={expired}
                />
              </div>

              <div className="flex items-start gap-2 text-[10px] text-warning bg-warning/10 rounded p-2">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>Pay first, then paste your transaction code within {ORDER_TTL_MIN} minutes. Duplicate codes are auto-rejected.</span>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" onClick={reset}>
                  Cancel
                </Button>
                <Button
                  size="sm"
                  className="flex-1"
                  disabled={submitting || expired || !transactionCode.trim()}
                  onClick={submitCode}
                >
                  Confirm
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  // Initial form
  return (
    <DashboardLayout>
      <AnimatedBackground />
      <div className="relative z-10 max-w-md mx-auto space-y-3 pb-10">
        <Card className="border-border/50 bg-card/60 backdrop-blur-md">
          <CardContent className="p-4 text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Wallet className="w-4 h-4 text-primary" />
              <h1 className="text-base font-bold">Add Balance</h1>
            </div>
            <div className="bg-gradient-to-r from-primary/30 to-primary/10 rounded-lg p-3 border border-primary/30">
              <p className="text-[10px] text-muted-foreground">Current Balance</p>
              <p className="text-2xl font-extrabold text-success">
                {format(profile?.wallet_points ?? 0)}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/60 backdrop-blur-md">
          <CardContent className="p-4 space-y-2">
            <label className="text-[10px] font-semibold flex items-center gap-1 text-muted-foreground uppercase">
              <DollarSign className="w-3 h-3" /> Amount (USD)
            </label>
            <Input
              type="number"
              min={1}
              max={5000}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount in USD"
              className="text-base font-bold h-10"
            />
            <div className="flex gap-1.5 flex-wrap">
              {QUICK_AMOUNTS.map((a) => (
                <Button
                  key={a}
                  size="sm"
                  variant={amount === String(a) ? "default" : "outline"}
                  onClick={() => setAmount(String(a))}
                  className="flex-1 min-w-[55px] h-8 text-xs"
                >
                  ${a}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/60 backdrop-blur-md">
          <CardContent className="p-4 space-y-2">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Payment Method
            </label>
            {methods.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground text-xs">
                <QrCode className="w-6 h-6 mx-auto mb-1 opacity-40" />
                No payment methods. Contact admin.
              </div>
            ) : (
              <div className="space-y-1.5">
                {methods.map((m) => {
                  const isSel = selectedMethod?.id === m.id;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelectedMethod(m)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-lg border-2 transition-all ${
                        isSel
                          ? "border-primary bg-primary/10"
                          : "border-border/50 hover:border-primary/40"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full border-2 ${
                          isSel ? "border-primary bg-primary" : "border-border"
                        } flex items-center justify-center`}>
                          {isSel && <div className="w-1.5 h-1.5 rounded-full bg-primary-foreground" />}
                        </div>
                        <div className="text-left">
                          <p className="font-semibold text-xs">{m.name}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {m.display_field === "id" ? "Pay by ID" : m.display_field === "both" ? "QR or ID" : "Scan QR"}
                          </p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Button
          className="w-full h-10 text-sm font-bold"
          onClick={createOrder}
          disabled={submitting || !amount || !selectedMethod}
        >
          <Plus className="w-4 h-4 mr-1" /> Create Order
        </Button>

        <p className="text-center text-[10px] text-muted-foreground">
          ⚡ {ORDER_TTL_MIN}-min order window · Pay then paste transaction code
        </p>

        {myRequests.length > 0 && (
          <Card className="border-border/50 bg-card/60 backdrop-blur-md">
            <CardContent className="p-3 space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold">
                <Clock className="w-3 h-3 text-primary" /> History
              </div>
              {myRequests.slice(0, 8).map((r: any) => (
                <div key={r.id} className="flex items-center justify-between text-[10px] p-1.5 rounded bg-background/40">
                  <div className="truncate">
                    <span className="text-success font-bold">{symbol}{r.amount_paid}</span>
                    <span className="text-muted-foreground ml-1">{r.payment_method}</span>
                    {r.transaction_code && <span className="text-muted-foreground ml-1">· {r.transaction_code}</span>}
                  </div>
                  <Badge variant={r.status === "approved" ? "default" : r.status === "rejected" ? "destructive" : "secondary"} className="text-[9px]">
                    {r.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
};

export default BuyCredit;
