import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Mail, Lock, User, KeyRound, Send } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type Mode = "login" | "signup" | "forgot" | "code";

const Auth = () => {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [lampOn, setLampOn] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (mode === "code") {
        const { data, error } = await supabase.functions.invoke("verify-access-code", {
          body: { email, code: accessCode.trim() },
        });
        if (error || !(data as any)?.ok) throw new Error((data as any)?.error || error?.message || "Invalid code");
        const { error: vErr } = await supabase.auth.verifyOtp({
          type: "magiclink",
          token_hash: (data as any).token_hash,
        });
        if (vErr) throw vErr;
        const scope = (data as any).scope;
        toast.success(`Logged in! Access: ${scope}`);
        navigate(scope === "topup" ? "/topup" : "/buy-credit");
        return;
      }

      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: window.location.origin,
        });
        if (error) throw error;
        toast.success("Password reset email sent!");
        return;
      }

      if (mode === "login") {
        const { data: signInData, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (signInData.user) {
          const { data: profile } = await supabase
            .from("profiles").select("is_approved, is_banned").eq("user_id", signInData.user.id).single();
          if (profile?.is_banned) {
            await supabase.auth.signOut();
            throw new Error("Your account has been banned.");
          }
          toast.success("Logged in!");
          navigate("/dashboard");
        }
      } else {
        // signup
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { data: { display_name: displayName }, emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created! You can now sign in.");
        setMode("login");
      }
    } catch (err: any) {
      toast.error(err.message || "Auth failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#1a1d2e] relative overflow-hidden transition-colors duration-700">
      <AnimatePresence>
        {lampOn && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.8 }} className="absolute inset-0 pointer-events-none">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-yellow-400/10 blur-[120px]" />
            <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[300px] h-[400px] bg-gradient-to-b from-yellow-300/15 via-yellow-200/5 to-transparent blur-[60px]" />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative z-20 flex flex-col items-center mb-8 cursor-pointer select-none" onClick={() => setLampOn(!lampOn)}>
        <div className="w-[3px] h-16 bg-gray-500/60" />
        <div className="w-16 h-4 bg-gray-500/80 rounded-b-lg" />
        <motion.div className="w-20 h-20 rounded-full flex items-center justify-center relative -mt-2"
          animate={{
            backgroundColor: lampOn ? "rgba(250, 204, 21, 0.9)" : "rgba(107, 114, 128, 0.5)",
            boxShadow: lampOn ? "0 0 60px 20px rgba(250, 204, 21, 0.4), 0 0 120px 40px rgba(250, 204, 21, 0.15)" : "0 0 0 0 transparent",
          }}
          transition={{ duration: 0.5 }}>
          {lampOn && <motion.div initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }} className="absolute inset-0 rounded-full bg-yellow-300/40 blur-xl" />}
        </motion.div>
        <p className="text-gray-400 text-xs mt-3 tracking-wider">Lamp (click)</p>
      </div>

      <AnimatePresence>
        {lampOn && (
          <motion.div initial={{ opacity: 0, y: 40, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 40, scale: 0.9 }} transition={{ duration: 0.5, ease: "easeOut" }} className="relative z-10 w-full max-w-sm px-6">
            <div className="text-center mb-6">
              <h1 className="text-2xl font-bold text-gray-100 tracking-wide">Member Login</h1>
              <p className="text-gray-400 text-sm mt-1">
                {mode === "forgot" ? "Reset your password" :
                  mode === "code" ? "Enter your one-time access code" :
                    mode === "login" ? "Sign in to continue" : "Create a new account"}
              </p>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              {mode === "signup" && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                    <Input placeholder="Username" value={displayName} onChange={(e) => setDisplayName(e.target.value)}
                      className="pl-10 bg-gray-800/60 border-gray-700/50 text-gray-100 placeholder:text-gray-500" />
                  </div>
                </motion.div>
              )}
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input type="email" placeholder="Gmail" value={email} onChange={(e) => setEmail(e.target.value)} required
                  className="pl-10 bg-gray-800/60 border-gray-700/50 text-gray-100 placeholder:text-gray-500" />
              </div>
              {(mode === "login" || mode === "signup") && (
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                  <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6}
                    className="pl-10 bg-gray-800/60 border-gray-700/50 text-gray-100 placeholder:text-gray-500" />
                </div>
              )}
              {mode === "code" && (
                <>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-3 h-4 w-4 text-cyan-400" />
                    <Input placeholder="6-digit access code" value={accessCode} onChange={(e) => setAccessCode(e.target.value)} required maxLength={6}
                      className="pl-10 bg-gray-800/60 border-gray-700/50 text-gray-100 placeholder:text-gray-500 font-mono tracking-widest text-center" />
                  </div>
                  <p className="text-[11px] text-gray-400 text-center leading-relaxed">
                    Telegram bot ma <code className="text-yellow-400">/login your@gmail.com</code> patau,<br />
                    admin le code dincha — yahan halnus.
                  </p>
                </>
              )}
              <Button type="submit" disabled={loading} className="w-full bg-yellow-500 hover:bg-yellow-400 text-gray-900 font-bold shadow-lg shadow-yellow-500/20">
                {loading ? "Loading..." :
                  mode === "forgot" ? "Send Reset Link" :
                    mode === "code" ? "Verify & Login" :
                      mode === "login" ? "Sign in" : "Sign Up"}
              </Button>
            </form>

            <div className="mt-4 text-center space-y-2">
              {(mode === "login" || mode === "signup") && (
                <button type="button" onClick={() => setMode("forgot")} className="text-sm text-gray-400 hover:text-yellow-400">
                  Forgot password?
                </button>
              )}
              <div className="flex flex-col gap-1">
                {(mode === "login" || mode === "signup") && (
                  <button type="button" onClick={() => setMode(mode === "login" ? "signup" : "login")} className="text-sm text-yellow-400 hover:underline">
                    {mode === "login" ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
                  </button>
                )}
                <button type="button" onClick={() => setMode(mode === "code" ? "login" : "code")} className="text-xs text-cyan-400 hover:underline flex items-center justify-center gap-1">
                  <Send className="w-3 h-3" /> {mode === "code" ? "Use email/password" : "Login with one-time code"}
                </button>
              </div>
              {mode === "forgot" && (
                <button type="button" onClick={() => setMode("login")} className="text-sm text-yellow-400 hover:underline">
                  Back to Sign In
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!lampOn && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-gray-600 text-sm mt-4 z-10">
            Turn on the lamp to login
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Auth;
